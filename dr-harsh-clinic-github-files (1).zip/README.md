# 🏥 DR. HARSH DIET & NUTRI CLINIC
### Premium, Mobile-First Website & Lead Generation Application

![Rating Badge](https://img.shields.io/badge/Google%20Rating-4.9%20%E2%98%85%E2%98%85%E2%98%85%E2%98%85%E2%98%85%20(192+%20Reviews)-0A5C36?style=for-the-badge&logo=google)
![Tailwind CSS](https://img.shields.io/badge/Built%20With-Tailwind%20CSS-38B2AC?style=for-the-badge&logo=tailwind-css)
![Responsive](https://img.shields.io/badge/Fully%20Responsive-Mobile%20%7C%20Tablet%20%7C%20Desktop-C5A059?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Production%20Ready-25D366?style=for-the-badge)

A beautifully engineered, state-of-the-art premium healthcare website built for **DR. HARSH DIET & NUTRI CLINIC**, led by **Dr. Harsh Mishra**, one of Jaipur's most celebrated and trusted clinical dieticians.

---

## 👨‍⚕️ Business Details & Leadership

* **Clinic Name:** DR. HARSH DIET & NUTRI CLINIC
* **Doctor:** Dr. Harsh Mishra
* **Headquarters:** Old Lata Cinema, S-56, Second Floor, Upasna Apna Bazar, Jhotwara Road, Jaipur, Rajasthan 302012
* **Direct Phone:** +91 98292 96679
* **Reputation:** 4.9 ★★★★★ (192+ Verified Reviews)

### 🏆 Prestigious Factual Credentials Featured
* **M.Sc (Dietetics & Clinical Nutrition)** — *Mysore University*
* **NDDY** — *Delhi*
* **CMS&ED (WHO)** — *IRMA Affiliated to WRMA, Geneva*
* **National Pride in Excellence Award 2023** — *Honored at ICMR - National Institute of Nutrition (NIN), Hyderabad*
* **Ideal Work Appreciation Award 2024** — *Maa Laxmi Devi Foundation*
* **Life Memberships:** *Nutrition Society of India (NSI)*, *Indian Dietetic Association (IDA)*, and *Nutrition & Natural Health Sciences Association*.

---

## 🌟 Key Functional Highlights

1. **Modern Medical Luxury Design:** Custom professional aesthetic styled with pure white backgrounds, deep emerald green (`#0A5C36`), soft mint gradients (`#EAF5F0`), and warm metallic gold accents (`#C5A059`).
2. **100% Standalone Offline Infallibility:** All 4 uploaded high-resolution authentic photographs and official credentials cards are embedded directly into the source code as **Base64 Data URIs**, ensuring the website renders immaculately with zero broken image links.
3. **Integrated Service Category Filter:** 21 premium specialized healthcare programs filterable instantly by *Weight & Fitness*, *Clinical & Chronic Rehab*, *Family & Pediatric*, and *Lifestyle & Special*.
4. **Interactive Diagnostic BMI & Calorie Calculator:** Allows visitors to calculate their physiological metrics instantly and pre-fills their recommended program into the booking portal.
5. **Interactive Full-Screen Lightbox Zoom:** Tapping any national award certificate or official credentials card expands it in a high-fidelity modal overlay.
6. **Frictionless Quick-Action Mobile Pillars:** Includes sticky top navigation, click-to-WhatsApp direct message launchers, and mobile sticky bottom call/book bars.
7. **End-to-End Integrated Appointment Portal:** A robust consultation booking popup paired with a custom success confirmation modal and direct WhatsApp summary forwarding.

---

## 📂 Repository File Structure

```text
├── README.md           # Professional project documentation & deployment roadmap
├── index.html          # Production website (Self-contained HTML/CSS/JS for total mobile immunity)
├── css/
│   └── style.css       # Custom stylesheets, keyframe animations, typography & luxury glassmorphism rules
├── js/
│   └── app.js          # Main application logic (Calculators, sliders, Tab filtering, and modals)
└── uploads/            # Raw source files of Dr. Harsh's authentic uploaded awards and photographs
    ├── unnamed.jpg     # Ideal Work Appreciation Award 2024
    ├── unnamed (1).jpg # Official Factual Credentials & Life Memberships Card
    ├── unnamed (2).jpg # National Pride in Excellence Award 2023 at ICMR - NIN
    └── unnamed (3).jpg # Excellence in Healthcare Stage Presentation
```

---

## 🚀 GitHub Pages Quick Deployment Guide

You can easily host this complete website for free on GitHub Pages in 3 simple steps:

### Step 1: Create Your GitHub Repository
1. Log into your GitHub account and click the **`+`** icon in the top right corner ➔ **New repository**.
2. Name your repository (e.g., `dr-harsh-clinic` or `dr-harsh-mishra.github.io`).
3. Set the repository to **Public** and click **Create repository**.

### Step 2: Upload These Files
1. On the new repository page, click **uploading an existing file**.
2. Drag and drop all the clean files (`index.html`, `README.md`, and the `css/`, `js/`, and `uploads/` folders).
3. Add a commit message (e.g., `"Initial commit of Dr. Harsh premium website"`) and click **Commit changes**.

### Step 3: Enable GitHub Pages
1. In your GitHub repository, go to **Settings** (the gear icon at the top).
2. Scroll down to the left sidebar and click **Pages**.
3. Under the **Branch** dropdown, select **`main`** (or `master`) and keep the folder as **`/ (root)`**.
4. Click **Save**. Within 1–2 minutes, your website will be live at:
   `https://<your-username>.github.io/<your-repo-name>/`

---

## 🛡️ Technical Architecture Note
To guarantee that the website operates flawlessly when clients download and open the file directly on their smartphones without a local web server, `index.html` has been bundled with inline `<style>` and `<script>` versions of `css/style.css` and `js/app.js`. For modular development and standard version control, the standalone modular source files in `css/` and `js/` remain fully structured and synchronized.

---
*Developed for Leading Healthcare Brand Authority & Maximum Lead Conversion.*
